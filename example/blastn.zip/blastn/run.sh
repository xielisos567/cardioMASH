#step 0. makedb
cd 15_genomes
for i in `ls ./`
do
        makeblastdb -in ./$i -dbtype nucl
done

#step1. BLASTN through the nucleotide database of cvdMGC
for i in `less ../15_genomes.txt`
do
        blastn -query ./combine_CVD_cds.fasta -db ../15_genomes/${i}.fna -evalue 1e-5 -perc_identity 80 -qcov_hsp_perc 80 -max_target_seqs 1 -out result/${i}.bls.fmt6 -outfmt "6 std gaps qcovs qcovhsp sseq" -num_threads 4
done

#step 2. Merge sequence alignment results
for i in `ls ./`; do cat ./$i | awk -v var="$i" '{print var"\t"$0}' >> ../combine_blastn_results_all.out; done

#step 3. ssANI filtering
python3 data-filter_ssANI2.py ANI_result.txt combine_blastn_results_all.out 15_genomes_ssANI.txt

#step4. cardioMASH annotation
python3 gene_cluster_extract_final_ssANI6-fragment.py gene_lable 15_genomes_ssANI.txt final_result2/15_genomes_annotation
